#!/usr/bin/env Rscript 
#
# Aim: calculate trial power based on meta-analysis data.
#
###############################################################

# load required libraries
library( "pwr" )
library( 'dplyr' )
library( 'ggplot2' )

###############################################################
# FUNCTIONS
###############################################################

###
# Return data.frame with meta-analysis tables of minimal number of entries; 
# (estimable == 'YES').
##
get.minimal.table.size <- function( df, min.entries = 5 )
{
	#output container
	out <- NULL

	for( rm5 in unique( df$rm5_input_file ) )
	{
		df1 <- df[ df$rm5_input_file == rm5, ]
		
		# loop over comparisons
		for( compID in unique( as.character( df1$compID ) ) )
		{
			df2 <- df1[ df1$compID == compID, ]
			
			# loop over sub-analyses
			for( subID in unique( as.character( df2$subID ) ) )
			{
				df3 <- df2[ df2$subID == subID, ]
				nr.estimable <- sum( df3$study_estimable == 'YES' )

				# add data with minimal number of estimable entries to output
				if( nr.estimable >= min.entries )
				{
					df3$min.estimable.entries <- nr.estimable

					# add to container
					out <- rbind( out, df3 )
				}
			}
		}
	}

	return( out )
}

###
# Calculate power for individual study based on population (~=meta) effect size.
##
get.power <- function( study.n1, study.n2, measure, meta.n1, meta.e1, meta.n2, meta.e2, effect.size, type = NA )
{
	if( is.na( study.n1 ) | is.na( study.n2 ) )
		return( data.frame( d = NA, power = NA ) ) 

	if( study.n1 < 3 | study.n2 < 3 )
		return( data.frame( d = NA, power = NA ) ) 

	# contineous outcome
	if( type == 'CONT' )
	{
		if( measure == 'MD' )
		{
			# return NA as data is not normalized/standardized and aggregate SD is not available in rm5-files.
			return( data.frame( d = NA, power = NA ) ) 
		}

		if( measure == 'SMD' )
		{
			est <- pwr::pwr.t2n.test( d = effect.size, n1 = study.n1, n2 = study.n2, sig.level = 0.05, alternative = "two.sided" )
			return( data.frame( d = effect.size, power = est$power ) ) 
		}
	}

	# dichotomous outcome
	if( type == 'DICH' )
	{
		if( measure[ 1 ] == 'OR' | measure[ 1 ] == 'PETO_OR' | measure[ 1 ] == 'RR' | measure[ 1 ] == 'RD' )
		{
			# Cohen's h, two different sample sizes [Cohen, J. (1988). Statistical power analysis for the behavioral sciences (2nd ed.). Hillsdale,NJ: Lawrence Erlbaum.]
			h <- pwr::ES.h( meta.e1 / meta.n1, meta.e2 / meta.n2 )
			est <- pwr.2p2n.test( h = h, n1 = study.n1, n2 = study.n2, sig.level = 0.05, alternative = "two.sided" )
			return( data.frame( d = h, power = est$power ) ) 
		}
	}

	if( ( type != 'CONT' ) & ( type != 'DICH' ) ){ stop( "*** ERROR ***: unknown data type in get.power()!" ) }
} 

###
# Return power for all studies based on original meta-analysis estimates given in rm5 files.
##
get.standard.power <- function( data )
{
	data$power <- NA
	data$d <- NA

	for( r in 1:nrow( data ) )
	{
		d <- data[ r, ]
		est <- get.power( study.n1 = d$study_total_1, study.n2 = d$study_total_2, measure = d$effect_measure, 
								meta.n1 = d$total_1, meta.e1 = d$events_1, meta.n2 = d$total_2, meta.e2 = d$events_2, 
								effect.size = d$effect_size, type = d$type )

		data[ r, 'power' ] <- est$power
		data[ r, 'd' ] <- est$d
	}

	return( data )
}

###
# Return data.frame with added power estimates.
##
add.power <- function( d )
{
	# only keep studies with estimable results
	data <- d[ d$study_estimable == 'YES', ]

	# add power without bias correction
	out <- get.standard.power( data )

	return( out )
}




###############################################################
# END FUNCTIONS
###############################################################

indir <- 'merged'
outdir <- 'merged.power'

# create outdir
dir.create( outdir, showWarnings = FALSE )

# read all tables
df <- read.csv( paste0( indir, '/merged.csv' ), row.names = 1 )

# minimal meta-analysis table size (estimable entries)
min.entries <- 5
df.select <- get.minimal.table.size( df, min.entries )

# add statistical power (for studies with 'estimable == YES')
df.power <- add.power( df.select )

# remove NA power
df.power <- df.power[ !is.na( df.power$power ), ]

# save data with powers
write.csv( df.power, paste0( outdir, '/data.power.csv' ) )


##########################
# PLOT
##########################

# combine group sizes
df.power$n <- df.power$study_total_1 + df.power$study_total_2

# make group
df.power$group <- as.factor( paste0( df.power$rm5_input_file, df.power$compID, df.power$subID ) )

# plot power ~ sample size, significant meta-analysis only
number_ticks <- function( n ) { function( limits ) pretty( limits, n ) }

p <- ggplot( data = df.power[ df.power$p_z < 0.05, ], aes( x = n, y = power, group = group, colour = group ) ) + 
		geom_point() + 
		geom_line() +
		xlab( "Total study sample size" ) +
		ylab( "Study power based on meta-analysis" ) +
		scale_y_continuous( breaks = number_ticks( 10 ) ) +
		theme_classic( base_size = 14 ) +
		theme( legend.position = 'none', axis.title = element_text( face = "bold" ), axis.text.x = element_text( angle = 45, hjust = 1 ) )

# log scale x-axis
p.log <- ggplot( data = df.power[ df.power$p_z < 0.05, ], aes( x = n, y = power, group = group, colour = group ) ) + 
		geom_point() + 
		geom_line() +
		xlab( "Total study sample size" ) +
		ylab( "Study power based on meta-analysis" ) +
		coord_trans( x = "log10" ) +
		scale_y_continuous( breaks = number_ticks( 10 ) ) +
		theme_classic( base_size = 14 ) +
		theme( legend.position = 'none', axis.title = element_text( face = "bold" ), axis.text.x = element_text( angle = 45, hjust = 1 ) )

# trim x axis to 0 - 3000
p.trim <- p + coord_cartesian( xlim = c( 0, 3000 ) )

# save plot
ggsave( plot = p, file = paste0( outdir, '/plot_samplesize-vs-power.png' ), dpi = 200, width = 8, height = 8 )
ggsave( plot = p.log, file = paste0( outdir, '/plot_samplesize-vs-power_log.png' ), dpi = 200, width = 8, height = 8 )
ggsave( plot = p.trim, file = paste0( outdir, '/plot_samplesize-vs-power_trim.png' ), dpi = 200, width = 8, height = 8 )

