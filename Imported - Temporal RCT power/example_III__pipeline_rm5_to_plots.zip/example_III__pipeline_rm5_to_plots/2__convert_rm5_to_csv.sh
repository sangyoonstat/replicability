#!/bin/bash
# get rm5 to csv converter from: https://osf.io/dxjy3/
#
# Aim: convert rm5 example files to csv files.
######################################################
mkdir converted 

bin/convert.rm5.to.csv.php data/CD002755.pub2.rm5 converted/CD002755.pub2.csv
bin/convert.rm5.to.csv.php data/CD000213.pub3.rm5 converted/CD000213.pub3.csv


