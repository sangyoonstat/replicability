#!/usr/bin/env Rscript 

# Aim merge rm5 converted csv files into one data.frame and save to csv
#######################################################################

# outdir
outdir <- 'merged'
dir.create( outdir, showWarnings = FALSE )

# container
all <- NULL


# data/CD002755.pub2.rm5

cds <- c( 'CD002755.pub2', 'CD000213.pub3' )

for( cd in cds )
{
	print( cd )
	rm5_file <- paste0( "converted/", cd, '.csv' )
	tmp <- read.csv( rm5_file )
	all <- rbind( all, tmp )
}

# get relevant columns
all <- all[ , c( 'study_total_1', 'study_total_2', 'rm5_input_file', 'compID', 'subID', 'p_z', 'study_estimable', 'effect_measure', 'total_1', 'total_2', 'events_1', 'events_2', 'effect_size', 'type' ) ]

# write to outdir
write.csv( all, file = paste0( outdir, '/merged.csv' ) )


