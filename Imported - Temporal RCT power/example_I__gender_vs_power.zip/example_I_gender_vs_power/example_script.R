###############################################################
#
# Example script: determine proportions of 
# sufficiently powered trials based on cleaned Cochrane data.
#
# w.m.otte@umcutrecht.nl
###############################################################

# load required library
library( 'plyr' )
 
# read data
head( df <- read.csv( 'power_with_gender_data_3.csv.gz', row.names = 1 ) )

# threshold
power <- 0.8

# binary var 'suff. power'
df$sufficient_powered <- 0
df[ df$power > power & ! is.na( df$power ), ]$sufficient_powered <- 1

# only keep significant meta-analyses
all <- df[ df$p_z < 0.05, ]

# create author combinations
all$author <- 'unknown'
all[ all$first_author_gender == 'male' & all$last_author_gender == 'male', 'author' ] <- 'both males'
all[ all$first_author_gender == 'female' & all$last_author_gender == 'female', 'author' ] <- 'both females'
all[ all$first_author_gender == 'female' & all$last_author_gender == 'male', 'author' ] <- 'female - male (last)'
all[ all$first_author_gender == 'male' & all$last_author_gender == 'female', 'author' ] <- 'male - female (last)'

# get proportion sufficiently powered
( prop.suff.power <- ddply( all, .( author ), summarise, sufficient = 100 * sum( sufficient_powered, na.rm = TRUE ) / length( sufficient_powered ) ) )

